# coding: utf-8
def getDirList( p ):
        p = str( p )
        if p=="":
              return [ ]
        if p[ -1] != "/":
             p = p+"/"
        a = os.listdir( p )
        b = [ x   for x in a if os.path.isdir( p + x ) ]
        return b
