
# coding: utf-8

# In[2]:

from numpy import *
import numpy
import time

def entropy(counts):
    '''Compute entropy.'''
    ps = counts/float(sum(counts))  # coerce to float and normalize
    ps = ps[nonzero(ps)]            # toss out zeros
    H = -sum(ps * numpy.log2(ps))   # compute entropy
    
    return H

def mi(x, y, bins):
    '''Compute mutual information'''
    counts_xy = histogram2d(x, y, bins=bins, range=[[0, 311335], [0, 311335]])[0]
    counts_x  = histogram(  x,    bins=bins, range=[0, 311335])[0]
    counts_y  = histogram(  y,    bins=bins, range=[0, 311335])[0]
    
    H_xy = entropy(counts_xy)
    H_x  = entropy(counts_x)
    H_y  = entropy(counts_y)
    
    return H_x + H_y - H_xy


# In[ ]:



